var gameConfig = {
    autoPlay: {
        defaultIndex: 2,
        values: [5, 10, 25, 50]
    },
  reelsStartPosition: [5,7,9,10,16],
  gameVer: 1.625,
  minChillVersion: "1.6.3",
  useWebAudio: false
};
