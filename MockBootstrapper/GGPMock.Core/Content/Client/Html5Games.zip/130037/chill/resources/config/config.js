var config = {
    "keepAliveTimeout": 10000,
    "jackpotTimer": 5000,
    "connectionTimeout": 25000,
    "realServer": 'localhost:8687/GGPHTTPHandler/',
    "demoServer": 'localhost:8687/GGPHTTPHandler/',

    "history": {
        "token": null,
        "url": 'localhost/GGPHistoryHandler/',
        "gameID": 0
    },
    "jointype": 0,
    "operatorid": 0,
    "ga": 'UA',
    "isHybrid": false,
    "lang": 'eng',
    "gameName": 'Genric Game Name',
    "langSupported": ['eng'],
    "regulationTypeID": 0,//defaults to NJ... SHOULD BE 0 as default, due to a lobby bug set to 7(NJ) hardcoded.
    "gametype": '130037',
    "gamecurrencycode": 'USD',
    "url":'http://www.888casino.com/404/',
    "888operatorxml": {
        "_888ClientData": {
            "CID": 0,
            "ClientVersion": 'html5-games',
            "IsFreePlay":0, // free play mode
            "ClientPlatform": 1,
            "ClientURL": 'www',
            "BrandID": 'generic',
            "SubBrandID": 1,
            "ProductPackage": 2,
            "ClientType": 0,
            "EnableOperatorData": 1,
            "GameLimits": -1
        }
    },
    "operatorxml": {
        "AnonymousData":{
            "PlayerBalance":0
        }
    },
    onError: {
        "isOn": false,
        "ajaxUrl": "http://888.com/debug/888.php"
    },
    nextGenFallback: true,
    debug: false,
    chillVer: "1.7.3"
};