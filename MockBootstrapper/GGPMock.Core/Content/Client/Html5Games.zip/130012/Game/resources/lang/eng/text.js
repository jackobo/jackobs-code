rl.games.Text = {
    number_format: "%CUR%%NUM%",
    decimal:".",
    seperator: ",",

    balance_sum: "$0",
    balance_text: "BALANCE",
    total_bet_text: "TOTAL BET",
    total_bet_sum: "$0",
    total_win_text: "TOTAL WIN",
    total_win_sum: "$0",
    cashierText: "$0",
    cardSumTextBust: "BUST",
    cardSumTextBJ: "BJ",
    limitsMax: "MAX: $0",
    limitsMin: "MIN: $0",
    you_win_text: "You win [/n] $0",
    insurance_win_text: "Insurance wins [/n] $0",
    insurance_lose_text: "Insurance bet won by house",
    insuranceText: "INSURANCE?",
    you_lose_text:"House wins [/n] $0",
    push_text:"Push",
    insurance_lose_text:"Insurance Lost $0",
    place_bets_text:"Place Your Bets Please!",
    insufficientFundsGame:"Your current balance is insufficient to perform this action.",
    maxBetMessageText:"The max bet for this spot is $0",
    turbo_alert_on_text:"Turbo Mode is on!",
    turbo_alert_off_text:"Turbo Mode is off!",
    shuffling_text:"Shuffling cards",

    //dialog
    dialogBtnYesText:"YES",
    dialogBtnNoText:"NO",

    dialogSoundQuestion: 'Do you want to play sound?',
    dialogSoundSubTitle:'SOUND?'
};