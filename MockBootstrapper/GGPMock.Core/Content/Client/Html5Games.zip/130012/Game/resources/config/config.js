var gameConfig = {
  gameVer: 1.59,
  useWebAudio: false,
  useSamsungAudioBug: true,
  minChillVersion: "1.6.3"
};
