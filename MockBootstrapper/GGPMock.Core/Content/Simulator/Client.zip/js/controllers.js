/*-----------------------------------------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------------------------------------*/
var mainController = app.controller('mainController', function ($scope, $http) {
	
	$scope.cids  = getCookie("888SimulatorClientIdIP") != null ? getCookie("888SimulatorClientIdIP").split(',') : new Array();
    $scope.logs = new Array();
    $scope.sw = true;
    $scope.RegressionScenario;
    $scope.cyclicSimulations = [];
    var cid = getCookie("888SimulatorClientId");
    $scope.$parent.cyclicSimulationClientId = cid ? cid : "";

    $scope.makeTextFile = function (text) {
        var data = new Blob([text], { type: 'text/json' });
        // If we are replacing a previously generated file we need to
        // manually revoke the object URL to avoid memory leaks.
        var textFile = window.URL.createObjectURL(data);
        return textFile;
    };

    $scope.download = function download(filename, text) {
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + text);
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }

    $scope.downloadRegressionScenario = function (ev) {
        var val = $("#ScenarioName").val();
        if (val == "") {
            toastr['error']("Please enter scenario name", "Not Good!");
        } else {
            val = val + ".json";
            $scope.download(val, JSON.stringify($scope.RegressionScenario));
            $('#stopRegressionButton').popover('hide');
            $('#stopRegressionButton2').click();
        }
    };

    $scope.saveDBRegressionScenario = function (ev) {
        var scenarioName = $("#ScenarioName").val();
        if (scenarioName == "") {
            toastr['error']("Please enter scenario name", "Not Good!");
        } else {

            $scope.RegressionScenario.BasicInfo.Name = scenarioName;
            var log = {
                Type: 'info',
                Message: 'Submitted Save Scenario for Scenario Name:' + scenarioName
            };
            $scope.logs.push(log);

            toastr['info']('Submitted Save Scenario for Scenario Name:' + scenarioName, "Looking good!");
            $http.post(Gen_Config["regressionCommander"] + '/saveRegressionScenario', $scope.RegressionScenario).success(function (responseData) {
                if (responseData.Type == 'error') {
                    var log = {
                        Type: 'danger',
                        Message: responseData.Message
                    };
                } else {
                    var log = {
                        Type: responseData.Type,
                        Message: responseData.Message
                    };
                }
                $scope.logs.push(log);
                toastr[responseData.Type](responseData.Message, responseData.Title);
            });

            $('#stopRegressionButton').popover('hide');
            $('#stopRegressionButton2').click();
        }
    };

    $scope.discardRegressionScenario = function(ev) {
        $scope.RegressionScenario = "";
        toastr['warning']("Scenario discarded", "Warning");
        $('#stopRegressionButton').popover('hide');
        $('#stopRegressionButton2').click();
    };

    $scope.exportLog = function (ev) {
        var x = "", log = $scope.logs;
        for (var i = 0; i < log.length; i++) {
            x += log[i]["Type"] + "   " + log[i]["Message"] + "\r\n";
        }
        ev.target.href = "data:text;charset=utf-8," + encodeURI(x);
        ev.target.download = "SimulatorLog.txt";

    };
    $scope.MockDisable = Gen_Config["GGPMockEnable"]!="true";


    $scope.clearLogs = function () {
        $scope.logs = new Array();
    };
    $scope.keyPressed = function (keyCode) {
        $scope.searchedValue = $("#gameNameInput").val().toLowerCase();
        $("#gameNameButton").parent().addClass("open");
        $('#gameNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };
    $scope.keyPressedBonus = function (keyCode) {
        $scope.searchedValue = $("#gameNameBonusInput").val().toLowerCase();
        $("#gameNameBonusButton").parent().addClass("open");
        $('#gameNameBonusUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };

    $scope.searchCyclic = function (CIDCycling) {

        $http.defaults.useXDomain = true;
        delete $http.defaults.headers.common['X-Requested-With'];
        $scope.CIDCycling = CIDCycling || $scope.cyclicSimulationClientId || $('#cyclicInput').val();
        $http.get(Gen_Config["simulatorServer"] + '/getCyclicSimulations?clientId=' + $scope.CIDCycling + '&nocache=' + new Date().getTime()).success(function (data) {
            $scope.cyclicSimulations = data;
        });
    };

    $scope.deleteCyclicSimulation = function (sim) {
        var log = {
            Type: 'info',
            Message: "Sumbmited delete cycling simulation request for client id " + $scope.CIDCycling + " and game " + sim.GameID
        };

        $scope.logs.push(log);
        toastr['info']("Sumbmited delete cycling simulation request for client id " + $scope.CIDCycling + " and game " + sim.GameID, "Looking good!");
        var toSend = {
            clientId: $scope.CIDCycling,
            gameId: sim.GameID
        };
        $http.post(Gen_Config["simulatorServer"] + '/deleteCyclicSimulation', toSend).success(function (responseData) {
            var log = {
                Type: responseData.Type,
                Message: responseData.Message
            };
            $scope.searchCyclic($scope.CIDCycling);
            $scope.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });

    };

    $scope.searchCyclic();

});
/*-----------------------------------------------------------------------------------------------------------------*/

var gameResultSimulation = app.controller('gameResultSimulation', function ($scope, $http) {

    var simulationRequest = {
        CID: 0,
        GameID: 0,
        ResultName: "",
        ResultValue: "",
        Multiply: 0,
        Icons: 0,
        Cyclic: false,
        Jackpot: "",
        createdAt: new Date()
    };
    var simulationBonusRequest = {
        CID: 0,
        GameID: 0,
        ResultName: "",
        ResultValue: "",
        Multiply: 1,
        Icons: 1
    };
	
    $scope.checkboxBonus = false;
    $scope.jackpotSimulation = false;
    $scope.cyclicSimulation = false;
    NProgress.start();
    $scope.searchedValue = "";
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];

    $http.get(Gen_Config["simulatorServer"] + '/getAllGames?time='+new Date().getTime()).success(function (data) {
        $scope.gameList = data;
        $scope.cids  = getCookie("888SimulatorClientIdIP") != null ? getCookie("888SimulatorClientIdIP").split(',') : new Array();
		
       	var cid = GetUrlValue2("cid");
	    $scope.selectedCID = cid!=null ? cid : "";
	    var gameType = parseInt(GetUrlValue2("gameType"));
	
		if (gameType && gameType > 0) {
			for (var i = 0; i < $scope.gameList.length; i++) {
				if ($scope.gameList[i]["GameID"] == gameType) {
					$scope.selectGame({Name: $scope.gameList[i]["Name"], GameID: gameType});
				}
			}
		}

	    var resultData = GetUrlValue2("resultData");
		$scope.gameResultData = resultData != null ? decodeURI(resultData) : ""; 
    }).
    error(function(data, status, headers, config) {
		toastr['error']("There is no connection with the Server!!!", "Oops an error has ocured!");
	});

	 $scope.selectCid = function(cid){
    	$scope.selectedCID = cid;
    };

    $scope.initPopover = function () {
        $('#popoverButton').popover({
            html: true,
            content: function () {
                return $('#popover_content_wrapper').html();
            }
        }).parent().delegate('button', 'click', function (a) {
            try {

                if (a.currentTarget.attributes.data.nodeValue == "searchCyclic")
                    $scope.$parent.searchCyclic();
                else if (a.currentTarget.attributes.data.nodeValue) {
                    var data = a.currentTarget.attributes.data.nodeValue;
                    var d = JSON.parse(data);
                    $scope.$parent.deleteCyclicSimulation(d);
                    if ($scope.cyclicSimulations.length == 1) {
                        $('#popoverButton').popover('hide');
                        setTimeout(function () {
                            $('#popoverButton').popover('show');
                        }, 1000);
                    }
                }
            } catch (err) {

            };
        });

    };

    $scope.reset = function () {
        $scope.selectedGameName = undefined;
        $scope.gameResultData = undefined;
        $scope.selectedGameresult = undefined;
        $scope.selectedGameID = undefined;
        $scope.selectedBonusGameName = undefined;
        $scope.gameBonusResultData = undefined;
        $scope.selectedBonusGameresult = undefined;
        toastr['info']("Fields have been reseted!", "Client");
        var log = {
            Type: 'info',
            Message: 'Game Result: simulation fields reseted!'
        };
        $scope.$parent.logs.push(log);

    };
    $scope.selectGame = function (game) {
        $scope.selectedGameName = game.Name;
        $scope.selectedGameID = game.GameID;
        
        $scope.selectedGameresult = "";
        $scope.gameResultData = "";
        if (game.Multiply == 1) {
            simulationRequest.Multiply = 1;
            $scope.iconMultiplier = 1;
        }
        $http.get(Gen_Config["simulatorServer"] + '/getGameresults?gameId=' + game.GameID).success(function (data) {
            $scope.gameResults = data;

        });
    };
    $scope.selectGameresult = function (gameResult) {
        $scope.selectedGameresult = gameResult.Name;
        simulationRequest.ResultName = gameResult.Name;
        $scope.gameResultData = gameResult.Value;
    };
    $scope.validateResultValue = function (s) {
        var pat = new RegExp("[a-z]|[A-Z]");
        return s != "" && !pat.test(s);
    };
    $scope.sendSimulation = function () {
        if ($scope.selectedCID) {
            saveCidInCookie($scope.selectedCID);
            //setCookie("888SimulatorClientId", $scope.selectedCID);

        }
        var sw;
        $scope.checkboxBonus && (simulationBonusRequest.GameID == 0) ? sw = false : sw = true;
	
        simulationRequest.Icons = $scope.iconMultiplier;
        simulationRequest.CID = $scope.selectedCID;
        if (simulationRequest.ResultName == "")
            simulationRequest.ResultName += new Date().getTime();

        if (simulationBonusRequest.ResultName == "")
            simulationBonusRequest.ResultName += new Date().getTime();

        simulationRequest.ResultValue = $scope.gameResultData;
        simulationRequest.Cyclic = $scope.cyclicSimulation;
        if ($scope.jackpotSimulation) {
            simulationRequest.Jackpot = $scope.jackpotResult;
        } else {
            simulationRequest.Jackpot = "";
        }
        simulationBonusRequest.ResultValue = $scope.gameBonusResultData;
        simulationBonusRequest.CID = simulationRequest.CID;
        simulationRequest.createdAt = new Date();
        simulationRequest.GameID = $scope.selectedGameID;

        if (sw) {
            if (simulationRequest.CID) {
                if (simulationRequest.GameID != 0) {
                    if (simulationRequest.ResultName != "0" || simulationRequest.ResultValue != "") {
                        if ($scope.validateResultValue(simulationRequest.ResultValue)) {
                            if (simulationRequest.Multiply == 0 || (simulationRequest.Multiply == 1 && simulationRequest.Icons > 0)) {

                                var log = {
                                    Type: 'info',
                                    Message: 'CID(' + simulationRequest.CID + '): simulation request ' + simulationRequest.ResultName + ' for game ' + simulationRequest.GameID
                                };
                                $scope.$parent.logs.push(log);
                                toastr['info']("Sumbmited simulation request for game " + simulationRequest.GameID, "Looking good!");

                                $http.post(Gen_Config["simulatorServer"] + '/submitSimulationRequest', simulationRequest).success(function (responseData) {
                                    if (responseData.Type == 'error') {
                                        var log = {
                                            Type: 'danger',
                                            Message: responseData.Message
                                        };
                                    } else {
                                        var log = {
                                            Type: responseData.Type,
                                            Message: responseData.Message
                                        };
                                    }
                                    $scope.$parent.logs.push(log);
                                    $scope.$parent.searchCyclic();
                                    toastr[responseData.Type](responseData.Message, responseData.Title);
                                });
                                if ($scope.checkboxBonus) {
                                    if ($scope.validateResultValue(simulationBonusRequest.ResultValue)) {
                                        var log = {
                                            Type: 'info',
                                            Message: 'CID(' + simulationRequest.CID + '): simulation request ' + simulationBonusRequest.ResultName + ' for game ' + simulationBonusRequest.GameID
                                        };
                                        $scope.$parent.logs.push(log);
                                        toastr['info']("Sumbmited Bonus simulation request for game " + simulationBonusRequest.GameID, "Looking good!");

                                        $http.post(Gen_Config["simulatorServer"] + '/submitSimulationRequest', simulationBonusRequest).success(function (responseData) {
                                            if (responseData.Type == 'error') {
                                                var log = {
                                                    Type: 'danger',
                                                    Message: responseData.Message
                                                };
                                            } else {
                                                var log = {
                                                    Type: responseData.Type,
                                                    Message: responseData.Message
                                                };
                                            }
                                            $scope.$parent.logs.push(log);
                                            toastr[responseData.Type](responseData.Message, responseData.Title);
                                        });
                                    } else {
                                        toastr['error']("The Bonus result value cannot contain strings", "Oops an error has ocured!");
                                    }
                                }
                                return;
                            }
                        } else {
                            toastr['error']("The Result value cannot contain strings", "Oops an error has ocured!");
                        }

                    }
                }
            }
        }

        toastr['error']("Some fields are missing or invalid", "Oops an error has ocured!");
    };

    $scope.keyPressed = function (keyCode) {
        $scope.$parent.keyPressed(keyCode);
    };
    $scope.keyPressedBonus = function (keyCode) {
        $scope.$parent.keyPressedBonus(keyCode);
    };
    $scope.selectBonusGame = function (game) {
        checkboxBonus = true;
        $scope.selectedBonusGameName = game.Name;
        $scope.selectedBonusGameID = game.GameID;
        simulationBonusRequest.GameID = game.GameID;
        $scope.gameBonusResultData = "";
        $scope.selectedBonusGameresult = "";

        $http.get(Gen_Config["simulatorServer"] + '/getGameresults?gameId=' + game.GameID).success(function (data) {
            $scope.gameBonusResults = data;
        });
    };
    $scope.selectBonusGameresult = function (gameResult) {
        $scope.selectedBonusGameresult = gameResult.Name;
        simulationBonusRequest.ResultName = gameResult.Name;
        $scope.gameBonusResultData = gameResult.Value;
    };
    $scope.initPopover();
    NProgress.done();
});
var ogsResultSimulation = app.controller('ogsResultSimulation', function ($scope, $http) {
    $http.get(Gen_Config["simulatorServer"] + '/getOGSGames').success(function (data) {
        $scope.ogsGameList = data;
    });
    $scope.selectGame = function (gameName) {
        $scope.selectedGameName = gameName;
        $http.get(Gen_Config["simulatorServer"] + '/getOGSGameResults?ogsGame=' + gameName).success(function (data) {
            $scope.ogsGameResults = data;
            $scope.selectedGameresult = data[1];
        });
    };
    $scope.selectGameresult = function (resultName) {
        $scope.selectedGameresult = resultName;
    };
    $scope.sendSimulation = function () {
        $http.get(Gen_Config["simulatorServer"] + "/submitOGSSimulation?ogsGame=" + $scope.selectedGameName + "&ogsResult=" + $scope.selectedGameresult + "&cid=" + $scope.selectedCID).success(function (responseData) {
            toastr[responseData.Type](responseData.Message, responseData.Title);
        }
        );
    };
});


/*-----------------------------------------------------------------------------------------------------------------*/

var errorResponseSimulation = app.controller('errorResponseSimulation', function ($scope, $http) {
    var errorSimulationRequest = {
        ClientId: 0,
        GameType: 0,
        OperationId: 0,
        ErrorCode: {}
    };
    var errorSimulation = {};
    NProgress.start();
    var cid = getCookie("888SimulatorClientId");
    $scope.selectedCID = cid ? cid : "";

    $http.defaults.headers.get = {
        'Content-Type': 'application/json'
    };
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];
    $http.get(Gen_Config["simulatorServer"] + '/getAllGames?time='+new Date().getTime()).success(function (data) {
        $scope.gameList = data;
    });
    $scope.reset = function () {
        $scope.selectedGameName = undefined;
        $scope.selectedGameOperationType = undefined;
        $scope.selectedGameError = undefined;
        $scope.selectedGameID = undefined;

        toastr['info']("Fields have been reseted!", "Client");
        var log = {
            Type: 'info',
            Message: 'Game Error Result: simulation fields reseted!'
        };
        $scope.$parent.logs.push(log);

    };
    $scope.selectGame = function (game) {
        $scope.selectedGameName = game.Name;
        $scope.selectedGameID = game.GameID;
        errorSimulationRequest.GameType = game.GameID;
        $scope.selectedGameOperationType = "";
        $scope.selectedGameError = "";
        $http.get(Gen_Config["simulatorServer"] + '/GetAvailableOperations?gameType=' + game.GameID).success(function (data) {
            $scope.operationTypeResults = data;
        });
    };
    $scope.selectOperation = function (op) {
        $scope.operationErrorsTypeResults = op.Errors;
        errorSimulationRequest.OperationId = op.Action.Id;
        errorSimulation.OperationName = op.Action.Name;
        $scope.selectedGameOperationType = op.Action.Name;
        $scope.selectedGameError = "";
    };
    $scope.selectError = function (error) {
        $scope.error = error;
        $scope.selectedGameError = error.Description;
        errorSimulationRequest.ErrorCode = error;
        errorSimulation.Name = error.Description;
    };
    $scope.sendSimulation = function () {
        if ($scope.selectedCID) {
            setCookie("888SimulatorClientId", $scope.selectedCID);
        }
        errorSimulationRequest.ClientId = parseInt($scope.selectedCID);

        if (errorSimulationRequest.ClientId)
            if (errorSimulationRequest.GameType != 0)
                if (errorSimulationRequest.OperationId != 0) {
                    if (errorSimulationRequest.ErrorCode != {}) {

                        var log = {
                            Type: 'info',
                            Message: 'Client Id(' + errorSimulationRequest.ClientId + '): game type ' + errorSimulationRequest.GameType + ', operation name ' + errorSimulation.OperationName + ', error name ' + errorSimulation.Name
                        };
                        $scope.$parent.logs.push(log);
                        toastr['info']("Sumbmited simulation request", "Looking good!");

                        $http.post(Gen_Config["simulatorServer"] + '/SimulateOperationError', errorSimulationRequest).success(function (responseData) {
                            if (responseData.Type == 'error') {
                                var log = {
                                    Type: 'danger',
                                    Message: responseData.Message
                                };
                            } else {
                                var log = {
                                    Type: responseData.Type,
                                    Message: responseData.Message
                                };
                            }
                            $scope.$parent.logs.push(log);
                            toastr[responseData.Type](responseData.Message, responseData.Title);
                        });
                        return;
                    }

                }

        toastr['error']("Some fields are missing or invalid", "Oops an error has ocured!");
    };
    $scope.keyPressed = function (keyCode) {
        $scope.$parent.keyPressed(keyCode);
    };
    NProgress.done();
});
/*-----------------------------------------------------------------------------------------------------------------*/

var addEnvironment = app.controller('insertResult', function ($scope, $http) {
    $scope.newSimulationRequest = {};
    NProgress.start();

    $http.defaults.headers.get = {
        'Content-Type': 'application/json'
    };
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];
    $http.get(Gen_Config["simulatorServer"] + '/getAllGames?time='+new Date().getTime()).success(function (data) {
        $scope.gameList = data;
    });
    $scope.newSimulationRequest.Full = "";
    $scope.selectGame = function (game) {
        $scope.selectedGameName = game.Name;
        $scope.newSimulationRequest.GameID = game.GameID;
    };

    $scope.sendSimulation = function () {
        if ($scope.newSimulationRequest.GameID != 0) {
            if ($scope.newSimulationRequest.Name != "") {
                if ($scope.newSimulationRequest.Value != "") {
                    if (!isNaN(parseInt($scope.newSimulationRequest.Full))) {

                        $http.post(Gen_Config["simulatorServer"] + '/insertResult', $scope.newSimulationRequest).success(function (responseData) {
                            if (responseData.Type == 'error') {
                                var log = {
                                    Type: 'danger',
                                    Message: responseData.Message
                                };
                            } else {
                                var log = {
                                    Type: responseData.Type,
                                    Message: responseData.Message
                                };
                            }
                            $scope.$parent.logs.push(log);
                            toastr[responseData.Type](responseData.Message, responseData.Title);
                        });
                        return;
                    }
                }
            }
        }
        toastr['error']("Some fields are missing or invalid", "Oops an error has ocured!");
    };
    $scope.keyPressed = function (keyCode) {
        $scope.$parent.keyPressed(keyCode);
    };
    NProgress.done();
});

var removeResult = app.controller('removeResult', function ($scope, $http) {

    var simulationRequest = {
        CID: 0,
        GameID: 0,
        Name: "",
        Value: "",
        Multiply: 0,
        Icons: 0,
        Cyclic: false,
        Jackpot: ""
    };
    NProgress.start();

    $http.defaults.headers.get = {
        'Content-Type': 'application/json'
    };

    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];
    $http.get(Gen_Config["simulatorServer"] + '/getAllGames?time='+new Date().getTime()).success(function (data) {
        $scope.gameList = data;
    });

    $scope.keyPressed = function (keyCode) {
        $scope.searchedValue = $("#removeGameNameInput").val().toLowerCase();
        $("#removeGameNameButton").parent().addClass("open");
        $('#removeGameNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };

    $scope.selectGame = function (game) {
        $scope.selectedGameName = game.Name;
        $scope.selectedGameID = game.GameID;
        simulationRequest.GameID = game.GameID;
        $scope.selectedGameresult = "";
        $scope.gameResultData = "";
        if (game.Multiply == 1) {
            simulationRequest.Multiply = 1;
            $scope.iconMultiplier = 1;
        }
        $http.get(Gen_Config["simulatorServer"] + '/getGameresults?gameId=' + game.GameID).success(function (data) {
            $scope.gameResults = data;

        });
    };
    $scope.selectGameresult = function (gameResult) {
        $scope.selectedGameresult = gameResult.Name;
        simulationRequest.Name = gameResult.Name;
        $scope.gameResultData = gameResult.Value;
        simulationRequest.Value = gameResult.Value;
    };


    $scope.sendRemoveSimulation = function () {
        if (simulationRequest.GameID != 0) {
            if (simulationRequest.Name != "") {
                if (simulationRequest.Value != "") {


                    $http.post(Gen_Config["simulatorServer"] + '/removeResult', simulationRequest).success(function (responseData) {
                        if (responseData.Type == 'error') {
                            var log = {
                                Type: 'danger',
                                Message: responseData.Message
                            };
                        } else {
                            var log = {
                                Type: responseData.Type,
                                Message: responseData.Message
                            };
                            $scope.selectedGameresult = "";
                            $scope.gameResultData = "";
                            $scope.selectGame({ "name": "", "GameID": simulationRequest.GameID });
                        }
                        $scope.$parent.logs.push(log);
                        toastr[responseData.Type](responseData.Message, responseData.Title);
                    });
                    return;

                }
            }
        }
        toastr['error']("Some fields are missing or invalid", "Oops an error has ocured!");
    };

    NProgress.done();
});

var addEnvironment = app.controller('insertGame', function ($scope, $http) {
    $scope.newSimulationRequest = {};
    NProgress.start();

    $scope.sendSimulation = function () {
        if ($scope.newGameRequest.GameID != 0) {
            if ($scope.newGameRequest.Name != "") {
                if ($scope.newGameRequest.Multiply != "") {
                    $http.post(Gen_Config["simulatorServer"] + '/insertGame', $scope.newGameRequest).success(function (responseData) {
                        if (responseData.Type == 'error') {
                            var log = {
                                Type: 'danger',
                                Message: responseData.Message
                            };
                        } else {
                            var log = {
                                Type: responseData.Type,
                                Message: responseData.Message
                            };
                        }
                        $scope.$parent.logs.push(log);
                        toastr[responseData.Type](responseData.Message, responseData.Title);
                    });
                    return;
                }
            }
        }
        toastr['error']("Some fields are missing or invalid", "Oops an error has ocured!");
    };
    NProgress.done();
});
var addEnvironment = app.controller('sendDisconnection', function ($scope, $http) {

    NProgress.start();
    $scope.sendDisco = function () {
        var request = {
            "GameId": $scope.GameId,
            "GameString": $("#gameString")[0].value,
            "GameType": $scope.GameType,
            "ClientId": $scope.ClientId,
            "InSubGame": $scope.InSubGame ? true : false
        };
        var log = {
            Type: 'info',
            Message: 'Submitted disconnection request for Client Id(' + $scope.ClientId + '): game type ' + $scope.GameType
        };
        $scope.$parent.logs.push(log);

        toastr['info']("Submitted disconnection request for game " + $scope.GameType, "Looking good!");
        $http.post(Gen_Config["simulatorServer"] + '/sendDisconnection', request).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
            }
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
    };
    NProgress.done();
});

var addEnvironment = app.controller('deleteCurrentSession', function ($scope, $http) {

    NProgress.start();
    $scope.deleteCurrentSession = function () {

        var request = {
            "GameType": $scope.GameType,
            "ClientId": $scope.ClientId
        };
        var log = {
            Type: 'info',
            Message: 'Submitted delete current session request for Client Id(' + $scope.ClientId + '): game type ' + $scope.GameType
        };
        $scope.$parent.logs.push(log);

        toastr['info']("Submitted delete current session request for game " + $scope.GameType, "Looking good!");
        $http.post(Gen_Config["simulatorServer"] + '/deleteCurrentSession', request).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
            }
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
    };
    NProgress.done();
});

var addEnvironment = app.controller('autoGenerateSimulations', function ($scope, $http) {

    NProgress.start();
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];
    $scope.simulations = new Array();
    var simulationRequest = {
        CID: 0,
        GameID: 0,
        ResultName: "",
        ResultValue: "",
        Multiply: 0,
        Icons: 0,
        Cyclic: false,
        Jackpot: ""
    };
    $http.get(Gen_Config["simulatorServer"] + '/getAllGames?time='+new Date().getTime()).success(function (data) {
        $scope.gameList = data;
    });

    $scope.xml = "Paste here the VIS game statistics file content. ";

    $scope.selectGame = function (game) {
        $scope.selectedGameName = game.Name;
        $scope.selectedGameID = game.GameID;
        simulationRequest.GameID = game.GameID;

    };

    $scope.clearContent = function () {

        $scope.xml = "";

    };
    $scope.parseFile = function () {

        $("#textAreaOutput").html($scope.gerSimulationString());
        toastr['success']("Parsing completed", "Successful!");
    };

    $scope.gerSimulationString = function () {
        var str = "";
        var xmlDoc = $.parseXML($scope.xml);
        var xml = $(xmlDoc);
        var name, i = 0;
        xml.find('Icon').each(function () {
            if ($(this)[0].attributes["name"]) {
                name = $(this)[0].attributes["name"]["value"];
                $scope.simulations[i] = {};
                $scope.simulations[i]["name"] = name;
                $scope.simulations[i]["value"] = $scope.getSimulString(xml, $(this)[0].attributes["id"]["value"]);
                str = str + name + "  " + $scope.simulations[i]["value"] + "\n";


                i++;
            }
        });
        return str;

    };

    $scope.getSimulString = function (doc, id) {
        var random = function (max) {
            return Math.floor(Math.random() * (max + 1));
        };
        var str = "";
        doc.find('ReelStrip[id=0]').each(function () {
            $(this).find('Reel').each(function () {
                var strArray = $(this)[0]["textContent"].split(",");
                var flag = false;
                for (var i = 0; i < strArray.length; i++) {
                    if (id == strArray[i]) {
                        if (i == 0) {
                            var num2 = strArray.length - 1;
                            str = str + num2 + " ";
                        } else {
                            str = str + ((i - 1)) + " ";
                        }
                        flag = true;
                        break;
                    }
                }
                if (!flag) {
                    str = str + random(strArray.length) + " ";
                }

            });
        });
        return str;
    };

    $scope.sendSimulations = function () {
        if (parseInt($scope.selectedGameID) != 0) {
            var i = 0;
            for (var i = 0; i < $scope.simulations.length; i++) {
                var newSimulationRequest = {
                    GameID: $scope.selectedGameID,
                    Name: $scope.simulations[i]["name"],
                    Value: $scope.simulations[i]["value"],
                    Full: 1
                };
                $http.post(Gen_Config["simulatorServer"] + '/insertResult', newSimulationRequest).success(function (responseData) {
                    if (responseData.Type == 'error') {
                        var log = {
                            Type: 'danger',
                            Message: responseData.Message
                        };
                    } else {
                        var log = {
                            Type: responseData.Type,
                            Message: responseData.Message
                        };
                    }
                    $scope.$parent.logs.push(log);
                    toastr[responseData.Type](responseData.Message, responseData.Title);
                });
            }
        } else {
            toastr['error']("Please choose a game", "Oops an error has ocured!");
        }

    };

    NProgress.done();
});


var GGPMock = app.controller('GGPMock',function($scope){
    var ws = new WebSocket("ws://localhost:8181");
    var recordContainer = document.getElementById("recordInfo");
    var recordEditor= new JSONEditor(recordContainer);

    $scope.records=[];
    $scope.index=0;
    $scope.status="stop";
    $scope.record=function(){
        $scope.status='record';
    };
    $scope.stop=function(){
        $scope.status='stop';
    };
    $scope.submit=function(){
        var request={
            Key:'SIMULATE_CUSTOM_RESPONSE',
            Data:JSON.stringify($scope.records)
        };
        ws.send(JSON.stringify(request));
        toastr['success']('Flow has been submited to GGPMock!');
        console.log(request);
    };
    $scope.removeAll=function(){
        $scope.records=[];
        $scope.$apply();
       recordEditor.set({
           data:'Nothing Yet'
       });
        $scope.recordEditorName='';
    };
    $scope.updateRecord=function(){
      console.log($scope.records[$scope.index]);
      $scope.records[$scope.index].Data = JSON.stringify(recordEditor.get());
      toastr['success']('Record has been updated!');
    };
    $scope.setRecordIndex=function(index){
        $scope.index=index;
        $scope.recordEditorName=$scope.records[index].Key;
        recordEditor.set(JSON.parse($scope.records[index].Data));
    };
    var container = document.getElementById("playerInfo");
    var editor = new JSONEditor(container);
    ws.onopen = function()
    {
       toastr['success']('Connected to GGPMock!');
    };
    ws.onmessage = function (evt)
    {
        var parsedData=JSON.parse(evt.data);
        if(parsedData.Key=="REFRESH_MOCK_DATA"){
            editor.set(JSON.parse(parsedData.Data));
        }else{
            toastr['info'](parsedData.Key);
            if($scope.status=='record'){
                $scope.records.push(parsedData);
                $scope.$apply();
                console.log($scope.records);
            }
        }
    };
    ws.onclose = function()
    {
        // websocket is closed.
        alert("Connection is closed...");
    };

    $scope.updatePlayerInfo= function () {
       toastr['info']('Updating player Info!');
       ws.send(
           JSON.stringify({
               Key:'SET_MOCK_DATA',
               Data:JSON.stringify(editor.get())
           })
       )
    }
});

var UserMaker = app.controller('UserMaker',/*['$location','$http','$scope',*/ function ($scope, $http, $location,sharedService) {
    $scope.userMakerRequest = {};
    $scope.userMakerRequest.Mail = "Obama@baitLavan.com";
    $scope.userMakerRequest.AddMoney = "0";
    $scope.userMakerRequest.Environment = "Mirage";
    $scope.userMakerRequest.Password = "12345678";
    console.log(Gen_Config["simulatorServer"]);
    $http.get(Gen_Config["simulatorServer"] + '/GetAllBrands?time=' + new Date().getTime()).success(function(data) {
        $scope.brandList = data;

        console.log(data);
    });
    $http.get(Gen_Config["simulatorServer"] + '/GetAllCountries?time=' + new Date().getTime()).success(function(data) {
        $scope.countryList = data;

        console.log(data);
    });
	

    $http.get(Gen_Config["simulatorServer"] + '/GetAllUsers?time=' + new Date().getTime()).success(function (data) {
        $scope.userList = data;
         console.log("User List: " + $scope.userList);
    });

    $scope.storageLocalData = [];
	if (typeof(Storage) !== "undefined") {
     //   toastr['info'](" We Have Local Storagwe whooo hoooo!");
        var i;
        for (i = 0; i < localStorage.length; i++)   { 
            var object = window.localStorage.getItem(localStorage.key(i));
            $scope.storageLocalData.push(JSON.parse(object));
        }  
		//console.log(JSON.stringify($scope.storageLocalData));
    }

//    console.log("MY USER NAME IS: " + username);
    console.log("UserMaker Mark 1 ");

    $http.defaults.headers.get = {
        'Content-Type': 'application/json'
    };
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];



    $scope.selectBrand = function (brand) {
        $scope.userMakerRequest.selectedBrandName = brand;
        console.log("here we are selectBrand ");

        $scope.selectedBrandresult = "";
        $scope.brandResultData = "";
     };


    $scope.keyPressed = function (keyCode) {
        console.log("here we are keyPressed #keycode ");
        $scope.searchedValue = $("#brandNameInput").val().toLowerCase();
        $("#brandNameButton").parent().addClass("open");
        $('#brandNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };

    $scope.selectVIP = function (vip) {
        $scope.userMakerRequest.selectedVIPName = vip;
        console.log("here we are dror4 ");

        $scope.selectedVIPresult = "";
        $scope.vipResultData = "";
    };

    $scope.keyPressedVIP = function (keyCode) {
        console.log("here we are keyPressedVIP #keycode ");
        $scope.searchedValue = $("#VIPNameInput").val().toLowerCase();
        $("#VIPNameButton").parent().addClass("open");
        $('#VIPNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };


    $scope.selectCountry = function (country) {
        $scope.userMakerRequest.selectedCountryName = country;
        console.log("here we are selectCountry ");

        $scope.selectedCountryresult = "";
        $scope.countryResultData = "";
        $scope.userMakerRequest.selectedStateName = "";
        $http.get(Gen_Config["simulatorServer"] + '/GetAllStates?country=' + country ).success(function (data) {
            $scope.stateList = data;
        })
            console.log("here we are GetAllStates ");
    };


    $scope.keyPressed = function (keyCode, paramType) {
        console.log("here we are keyPressed generic #keycode ");
        $scope.searchedValue = $("#"+paramType+"Input").val().toLowerCase();
        $("#"+paramType+"Button").parent().addClass("open");
        $('#'+paramType+'Ul li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };




    $scope.selectState = function (state) {
        $scope.userMakerRequest.selectedStateName = state;
        console.log("here we are selectState ");

        $scope.selectedStateresult = "";
        $scope.stateResultData = "";
    };

    $scope.updateUserFromDB = function (cid, env, whiteList) {
        var userInfo = {
            Cid: cid,
            Env: env,
            WhiteList: whiteList
        };
        sharedService.addParams(userInfo);
        console.log("Service sharedParams Is: " + sharedService.getParams());
        console.log($location);
        $location.url('UserUpdate')
    };


    NProgress.start();
    $scope.createUser = function () {
        console.log("here we are createUser ");

        var request = {
            "Name": $scope.userMakerRequest.UserName,
            "Brand": $scope.userMakerRequest.selectedBrandName,
            "CountryName": $scope.userMakerRequest.selectedCountryName,
            "StateName": $scope.userMakerRequest.selectedStateName,
            "Mail": $scope.userMakerRequest.Mail,
            "WhiteList": $scope.userMakerRequest.WhiteList,
            "RemovePending": $scope.userMakerRequest.RemovePending,
            "VIP": $scope.userMakerRequest.selectedVIPName,
            "BankrollAmount": $scope.userMakerRequest.AddMoney,
            "Env": $scope.userMakerRequest.Environment,
            "Currency": $scope.userMakerRequest.Currency,
            "Password": $scope.userMakerRequest.Password

        };

        var log = {
            Type: 'info',
            Message: 'Submitted create user request for user name (' + $scope.userMakerRequest.UserName + '): brand ' + $scope.userMakerRequest.selectedBrandName
        };

        $scope.$parent.logs.push(log);

        toastr['info']("Submitted createUser request for user " + $scope.userMakerRequest.UserName, "Looking good!");
        $http.post(Gen_Config["simulatorServer"] + '/createUserRequest', request).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                toastr['info']("Submitted createUser request for user " + $scope.userMakerRequest.UserName, "Succeeded!" + responseData.Message);
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };

        /* here to delete from/
		var cid = responseData.Message.substring(responseData.Message.indexOf("cid:")+5,responseData.Message.indexOf(". "));
        var errorRemark =  (responseData.Message.indexOf("failed!")==-1) ? "" : responseData.Message.substring(responseData.Message.indexOf("failed!")+8);
                console.log("The index of failed! is : " + responseData.Message.indexOf("failed!"));
                var row = {'name': $scope.userMakerRequest.UserName, 'password': $scope.userMakerRequest.Password, 'cid': cid, 'env':$scope.userMakerRequest.Environment, 'currency':$scope.userMakerRequest.Currency, 'whiteList':$scope.userMakerRequest.WhiteList, 'error': errorRemark};
                console.log("Save To Local Storage:  ");
                console.log(JSON.stringify(row));
                localStorage.setItem(cid, JSON.stringify(row));
         / here to delete till */
            }
            console.log("here we are end of createUser ");
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
    };
    NProgress.done();


}/*]*/);

var UserUpdate = app.controller('UserUpdate', function($scope, $http,sharedService) {
    console.log("starting UserUpdate ");
    console.log(Gen_Config["simulatorServer"]);

    $http.get(Gen_Config["simulatorServer"] + '/GetAllClientTypes?time=' + new Date().getTime()).success(function(data) {
        $scope.clientTypeList = data;

        console.log(data);
    });
        $http.get(Gen_Config["simulatorServer"] + '/GetAllLoyaltyTypes?time=' + new Date().getTime()).success(function(data) {
            $scope.loyaltyTypeList = data;

        console.log(data);
        console.log(data);
    });

    $scope.init = function () {
        var updatedparams = sharedService.getParams();
        $scope.userUpdateRequest = {};
        if(updatedparams != null) {
            $scope.userUpdateRequest.CID = updatedparams.Cid;
            $scope.userUpdateRequest.Environment = updatedparams.Env;
            $scope.userUpdateRequest.WhiteList = updatedparams.WhiteList;
            console.log("updateParams = ", updatedparams);
        }
    };

    $http.get(Gen_Config["simulatorServer"] + '/GetAllUsers?time=' + new Date().getTime()).success(function (data) {
            $scope.userList = data;
        console.log("User List: " + JSON.stringify($scope.userList));
        }).
    error(function (data, status, headers, config) {
        toastr['error']("There is no connection with the Server!!!", "Oops an error has ocured!");
    });




    $scope.storageLocalData = [];
    if (typeof(Storage) !== "undefined") {
   //     toastr['info'](" We Have Local Storagwe whooo hoooo!");
        var i;
        for (i = 0; i < localStorage.length; i++) {
            var object = window.localStorage.getItem(localStorage.key(i));
            $scope.storageLocalData.push(JSON.parse(object));
            window.localStorage.removeItem(localStorage.key(i));
            console.log("localStorage exist!!!");
        }
    }

    angular.forEach($scope.storageLocalData, function (value, key) {
        console.log("localStorage forEach exist!!!");
        console.log(key);
        // object = JSON.parse(value)
        var request = {
            "Environment": value.env,
            "CID": value.cid,
            "UserName": value.name,
            "Password": value.password,
            "Currency": value.currency,
            "WhiteList": value.whiteList
        };
        $http.post(Gen_Config["simulatorServer"] + '/addUserToDB', request).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                toastr['info']("Submitted update user on server - user " + value.name, "Succeeded!");
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
                console.log(key, value);
            }});
        });
    $scope.userUpdateRequest = {};
//    $scope.userUpdateRequest.selectedClientTypeName = "NEW1";

    $scope.selectClientType = function (clientType) {
        $scope.userUpdateRequest.selectedClientTypeName = clientType;
        console.log("here we are selectClientType ");
        $scope.selectedClientTyperesult = "";
        $scope.clientTypeResultData = "";
    };



    $scope.getUserName = function (userCid,env) {
        console.log("here we are selectUserName " + userCid +"env= " +env );
        $http.get(Gen_Config["simulatorServer"] + '/GetUserName?cid=' + userCid + '&env=' + env ).success(function(data) {
            $scope.selectedUserName = data;
            console.log("selectedUserName");
            console.log($scope.selectedUserName);
        });
    };

    $scope.getToken = function (userCid,env) {

        console.log("here we are getToken " + userCid +"env= " +env );
        $http.get(Gen_Config["simulatorServer"] + '/GetToken?cid=' + userCid + '&env=' + env ).success(function(data) {
            $scope.selectedToken = data;
            console.log("selectedToken");
            console.log($scope.selectedToken);
        });

    };
	
    $scope.keyPressed = function (keyCode, paramType) {
        console.log("here we are keyPressed generic #keycode ");
        $scope.searchedValue = $("#"+paramType+"Input").val().toLowerCase();
        $("#"+paramType+"Button").parent().addClass("open");
        $('#'+paramType+'Ul li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };

    $scope.keyPressedClientType = function (keyCode) {
        console.log("here we are keyPressedClientType #keycode ");
        $scope.searchedValue = $("#clientTypeNameInput").val().toLowerCase();
        $("#clientTypeNameButton").parent().addClass("open");
        $('#clientTypeNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };


    $scope.selectLoyaltyType = function (loyaltyType) {
        $scope.userUpdateRequest.selectedLoyaltyTypeName = loyaltyType;
        console.log("here we are selectLoyaltyType ");

        $scope.selectedLoyaltyTyperesult = "";
        $scope.loyaltyTypeResultData = "";

    };


    $scope.updateUserFromDB = function (cid, env, whiteList) {
        $scope.userUpdateRequest.CID = cid;
        $scope.userUpdateRequest.Environment = env;
        $scope.userUpdateRequest.WhiteList = whiteList;
        console.log("here we are update User from cid ");
    };

    $scope.deleteUserFromLocalStorage = function (cid) {
        localStorage.removeItem(cid);
        console.log("here we are deleteUserFromLocalStorage cid " + cid);
    };


    $scope.keyPressedLoyaltyType = function (keyCode) {
        console.log("here we are keyPressedLoyaltyType #keycode ");
        $scope.searchedValue = $("#loyaltyTypeNameInput").val().toLowerCase();
        $("#loyaltyTypeNameButton").parent().addClass("open");
        $('#loyaltyTypeNameUl li').each(function () {
            var li = $(this);
            if (li.text().toLowerCase().indexOf($scope.searchedValue) > -1) {
                li.show();
            } else {
                li.hide();
            }
        });
    };
    $scope.userUpdateRequest.Environment = "Mirage"
    NProgress.start();



    $scope.deleteUserFromUserDB = function (cid) {
        console.log("here we are deleteUserFromDB ");

        var log = {
            Type: 'info',
            Message: 'Submitted update user request for cid: ' + $scope.userUpdateRequest.CID
        };

        $scope.$parent.logs.push(log);
        toastr['info']("Submitted updateUser request for cid: " + $scope.userUpdateRequest.CID, "Looking good!");
        $http.post(Gen_Config["simulatorServer"] + '/deleteUserFromDb', cid).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                toastr['info']("delete user from local DB request for cid " + cid, "Succeeded!" + responseData.Message);
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
            }
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
        console.log("here we are end of deleteUserFromDB ");
    };






    $scope.updateUser = function () {
        console.log("here we are updateUser ");

        var request = {
            "CID": $scope.userUpdateRequest.CID,
            "MoneyOperation": $scope.userUpdateRequest.MoneyOperation,
            "Amount": $scope.userUpdateRequest.Amount,
            "Currency": $scope.userUpdateRequest.Currency,
            "WhiteList": $scope.userUpdateRequest.WhiteList,
            "RemovePending": $scope.userUpdateRequest.RemovePending,
            "Env": $scope.userUpdateRequest.Environment,
            "FpOperation": $scope.userUpdateRequest.FpOperation,
            "PromotionId": $scope.userUpdateRequest.PromotionId,
            "ClientType": $scope.userUpdateRequest.selectedClientTypeName,
            "LoyaltyType": $scope.userUpdateRequest.selectedLoyaltyTypeName,
            "UserNameReq": $scope.userUpdateRequest.UserNameReq,
            "TokenReq": $scope.userUpdateRequest.TokenReq,
            "Kick2Lobby": $scope.userUpdateRequest.Kick2Lobby,
            "KickFromClient": $scope.userUpdateRequest.KickFromClient
        };

        var log = {
            Type: 'info',
            Message: 'Submitted update user request for cid: ' + $scope.userUpdateRequest.CID
        };

        $scope.$parent.logs.push(log);
        toastr['info']("Submitted updateUser request for cid: " + $scope.userUpdateRequest.CID, "Looking good!");
        $http.post(Gen_Config["simulatorServer"] + '/updateUserRequest', request).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                toastr['info']("Submitted updateUser request for cid " + $scope.userUpdateRequest.CID, "Succeeded!" + responseData.Message);
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
            }
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
        console.log("here we are end of UserUpdate ");
        NProgress.done();
    };
});


app.service('sharedService', function() {
    var sharedList;

    var addParams = function(newObj) {
        sharedList = newObj;
    };

    var getParams = function(){
        return sharedList;
    };


    return {
        addParams: addParams,
        getParams: getParams
    };

});



var RegressionRecording = app.controller('RegressionRecording', function ($scope, $http)
{
    NProgress.start();

    
    $scope.startRecording = function () {
        var log = { Type: 'info',  Message: 'Submitted Start Regression Recording for Client Id(' + $scope.ClientId + '): game type ' + $scope.GameType };
        $scope.$parent.logs.push(log);

        toastr['info']("Submitted Start Regression Recording for game " + $scope.GameType, "Looking good!");
        $http.get(Gen_Config["regressionCommander"] + '/startRecording?gameType=' + $scope.GameType + '&clientId=' + $scope.ClientId).success(function (responseData) {
            if (responseData.Type == 'error') {
                var log = {
                    Type: 'danger',
                    Message: responseData.Message
                };
            } else {
                var log = {
                    Type: responseData.Type,
                    Message: responseData.Message
                };
            }
            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
        });
    };

    $scope.stopRecording = function () {
        var log = { Type: 'info', Message: 'Submitted Stop Regression Recording for Client Id(' + $scope.ClientId + '): game type ' + $scope.GameType };
        $scope.$parent.logs.push(log);

        toastr['info']("Submitted Stop Regression Recording for game " + $scope.GameType, "Looking good!");
        $http.get(Gen_Config["regressionCommander"] + '/stopRecording?gameType=' + $scope.GameType + '&clientId=' + $scope.ClientId).success(function (responseData) {
            if (responseData == undefined) {
                var log = { Type: 'danger', Message: 'Failed to get regression scenario' };
                toastr['error']("Failed to get regression scenario", 'Server');
            } else {
                var log = { Type: 'success', Message: JSON.stringify(responseData) };
                toastr['success']('Regression scenario retrieved', 'Server');
                $scope.$parent.RegressionScenario = responseData;
                $('#stopRegressionButton2').click();
            }

            $scope.$parent.logs.push(log);
        });
    };

    $scope.initPopover = function () {
        $('#stopRegressionButton2').popover({
            html: true,
            maxWidth:"900px",
            content: function () {
                if (typeof ($scope.$parent.RegressionScenario) == "undefined" || $scope.$parent.RegressionScenario == "")
                    return null;
                return $('#popover_regression_scenario').html();
            }
        }).parent().delegate('button', 'click', function (a) {
            try {
                
                if (a.currentTarget.attributes.data.nodeValue == "downloadRegressionScenario"){
                    $scope.$parent.downloadRegressionScenario(a);
                }
                if (a.currentTarget.attributes.data.nodeValue == "discardRegressionScenario"){
                    $scope.$parent.discardRegressionScenario(a);
                }
                if (a.currentTarget.attributes.data.nodeValue == "saveDBRegressionScenario") {
                    $scope.$parent.saveDBRegressionScenario(a);
                }
                
            } catch (err) {

            };
        });
    };

   

    $scope.initPopover();
    NProgress.done();
});


var RegressionSaveScenario = app.controller('RegressionSaveScenario', function($scope, $http) {
    NProgress.start();

    $scope.saveScenario = function() {
        var name = $scope.Name;
        var text = $scope.Text;

        if (name == undefined || name == "") {
            toastr['error']("Please enter scenario name", "Not Good!");
        } else if (text == undefined || text == "") {
            toastr['error']("Please enter scenario text", "Not Good!");
        } else {

            var scenario = JSON.parse(text);
            scenario.BasicInfo.Name = name;

            var log = {
                Type: 'info',
                Message: 'Submitted Save Scenario for Scenario Name:' + name
            };
            $scope.$parent.logs.push(log);

            toastr['info']('Submitted Save Scenario for Scenario Name:' + name, "Looking good!");
            $http.post(Gen_Config["regressionCommander"] + '/saveRegressionScenario', scenario).success(function (responseData) {
                if (responseData.Type == 'error') {
                    var log = {
                        Type: 'danger',
                        Message: responseData.Message
                    };
                } else {
                    var log = {
                        Type: responseData.Type,
                        Message: responseData.Message
                    };
                    $scope.Name = undefined;
                    $scope.Text = undefined;
                }
                $scope.$parent.logs.push(log);
                toastr[responseData.Type](responseData.Message, responseData.Title);
            });
        }
    };

    NProgress.done();
});

var RegressionViewScenarios = app.controller('RegressionViewScenarios', function ($scope, $http) {
    NProgress.start();

    $scope.getScenarios = function () {
        var gameType = $scope.GameType;
        var log;
        if (gameType == undefined || gameType == "") {
            gameType = 0;
            log = { Type: 'info', Message: 'Submitted Get Scenarios for all GameTypes' };
            toastr['info']('Submitted Get Scenarios for all GameTypes', "Looking good!");
        } else {
            log = { Type: 'info', Message: 'Submitted Get Scenarios for GameType:' + gameType };
            toastr['info']('Submitted Get Scenarios for GameType:' + gameType, "Looking good!");
        }

        $scope.$parent.logs.push(log);
        $http.get(Gen_Config["regressionCommander"] + '/getScenarios?gameType=' + gameType).success(function (responseData) {
            if (responseData != undefined && responseData.length > 0) {
                toastr['success']('Scenarios found', "Server");
            } else {
                toastr['error']('No scenarios found', "Server");
            }
            $scope.scenarios = responseData;
        });
    };

    $scope.deleteScenario = function(scenario) {
        var log = { Type: 'info', Message: 'Deleting scenario:' + scenario.Name + ' gameType: ' + scenario.GameType };
        $scope.$parent.logs.push(log);

        $http.post(Gen_Config["regressionCommander"] + '/deleteScenario', scenario).success(function (responseData) {
            if (responseData.Type == 'error') {
                log = { Type: 'danger', Message: responseData.Message };
            } else {
                log = { Type: responseData.Type, Message: responseData.Message };
            }

            $scope.$parent.logs.push(log);
            toastr[responseData.Type](responseData.Message, responseData.Title);
            $scope.getScenarios();
        });
    }

    $scope.downloadScenario = function(scenario) {
        var log = { Type: 'info', Message: 'Downloading scenario:' + scenario.Name + ' gameType: ' + scenario.GameType };
        $scope.$parent.logs.push(log);
        var scenarioName = scenario.GameType + '_' + scenario.Name;

        $http.get(Gen_Config["regressionCommander"] + '/downloadScenario?gameType=' + scenario.GameType + '&name=' + scenario.Name).success(function (responseData) {
            if (responseData != undefined && responseData != "") {
                $scope.$parent.download(scenarioName, JSON.stringify(responseData));
                log = { Type: 'info', Message: 'Scenario downloaded:' + scenarioName};
                toastr['success']('Scenario downloading', "Server");
            } else {
                log = { Type: 'danger', Message: 'Scenario failed to download:' + scenarioName };
                toastr['error']('Scenario not found', "Server");
            }

            $scope.$parent.logs.push(log);
        });
    }

    NProgress.done();
});


