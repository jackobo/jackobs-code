/* Navbar toggles */
$("#navigation li").click(function(){
  $("#navigation li").removeClass('active');
  $("#"+this.id).addClass('active');

});
/* Navbar toggles */

var app = angular.module('GGPSimulator',[]);


app.config(['$routeProvider',function($routeProvider){
	$routeProvider.when('/',{templateUrl:'views/gameResultSimulation.html',controller:'gameResultSimulation'});
	$routeProvider.when('/ogs',{templateUrl:'views/ogsResultSimulation.html',controller:'ogsResultSimulation'});
	$routeProvider.when('/InsertResult',{templateUrl:'views/insertResult.html',controller:'insertResult'});
	$routeProvider.when('/InsertGame',{templateUrl:'views/insertGame.html',controller:'insertGame'});
	$routeProvider.when('/AutoGenerateGameSimulations',{templateUrl:'views/autoGenerateGameSimulations.html',controller:'autoGenerateSimulations'});
	$routeProvider.when('/RemoveResult',{templateUrl:'views/removeResult.html',controller:'removeResult'});
	$routeProvider.when('/SendDisconnection',{templateUrl:'views/sendDisconnection.html',controller:'sendDisconnection'});
	$routeProvider.when('/IPErrorSimulation',{templateUrl:'views/IPErrorSimulation.html',controller:'ipErrorSimulation'});
    /*$routeProvider.when('/GGPMock',{templateUrl:'views/GGPMock.html',controller:'GGPMock'});*/
    $routeProvider.when('/UserMaker',{templateUrl:'views/UserMaker.html',controller:'UserMaker'});
    $routeProvider.when('/UserUpdate', { templateUrl: 'views/UserUpdate.html', controller: 'UserUpdate' });

    $routeProvider.when('/RegressionRecording', { templateUrl: 'views/RegressionRecording.html', controller: 'RegressionRecording' });
    $routeProvider.when('/RegressionSaveScenario', { templateUrl: 'views/RegressionSaveScenario.html', controller: 'RegressionSaveScenario' });
    $routeProvider.when('/RegressionViewScenarios', { templateUrl: 'views/RegressionViewScenarios.html', controller: 'RegressionViewScenarios' });

    /*$routeProvider.when('/ResetSimulationMode',{templateUrl:'views/resetSimulationMode.html',controller:'resetSimulationMode'});
    $routeProvider.when('/AddEnvironment',{templateUrl:'views/addEnvironment.html',controller:'addEnvironment'});
    $routeProvider.when('/AddGameserver',{templateUrl:'views/addGameserver.html',controller:'addGameserver'});*/
}]);



app.directive('onKeyup', function($parse) {
    return function(scope, elm, attrs) {
        //Evaluate the variable that was passed
        //In this case we're just passing a variable that points
        //to a function we'll call each keyup
        var keyupFn = $parse(attrs.onKeyup);
        elm.bind('keyup', function(evt) {
            //$apply makes sure that angular knows 
            //we're changing something
            scope.$apply(function() {
                keyupFn(scope, {$key: evt.which});
            });
        });
    };
});

app.directive('onClick', function($parse) {
    return function(scope, elm, attrs) {
        //Evaluate the variable that was passed
        //In this case we're just passing a variable that points
        //to a function we'll call each keyup
        var clickFn = $parse(attrs.onClick);
        elm.bind('click', function(evt) {
            //$apply makes sure that angular knows 
            //we're changing something
            scope.$apply(function() {
                clickFn(scope, {$key: evt.which});
            });
        });
    };
});

app.directive('myRepeatDirective', function() {
  return function(scope, element, attrs) {
    
    if (scope.$first){
		$('#popoverButton').popover('hide');
    }
    
    if (scope.$last){
      setTimeout(function (){

      $('#popoverButton').popover('show');

         }, 1000);
      
    }
  };
});




