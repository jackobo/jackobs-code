/**
 * @author adrianpa
 */
var Gen_Config = {
	//"simulatorServer":"http://10.20.70.126/API/GGPSimulator/admin"
    "simulatorServer": "http://localhost:8687/API/GGPSimulator/admin",
    "regressionCommander": "http://localhost:8687/API/RegressionCommander",
    "GGPMockEnable": "false"


};