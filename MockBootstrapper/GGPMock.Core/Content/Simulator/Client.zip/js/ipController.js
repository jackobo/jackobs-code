
var ipErrorSimulation = app.controller('ipErrorSimulation', function ($scope, $http) {

    NProgress.start();
    $scope.operationErrors = new Array();
    $scope.operationChosen = true;
    $scope.UGSReason = null;
    $scope.editedOperation = null;
    $scope.operations = new Array();
    $scope.showUGS = false;
    $scope.Errors = new Array();
    $scope.cids = getCookie("888SimulatorClientIdIP") != null ? getCookie("888SimulatorClientIdIP").split(',') : new Array();
    $scope.ipOperations = [{ "name": "Debit" }, { "name": "CancelDebit" }, { "name": "UpdateGameState" }, { "name": "GetFreePlayDetails" }, { "name": "FinishFreePlayDetails" }, { "name": "JackpotWinning" }, { "name": "StartGameSession" }, { "name": "EndGameSession"}];
    $scope.BipOperations = [{ "name": "AuthenticateUser" }, { "name": "DebitFunds" }, { "name": "CreditFunds" }, { "name": "EndGame" }, { "name": "StartFreeGame" }, { "name": "EndFreeGame"}];
    $scope.Operators = [{ "name": "888" }, { "name": "Bingo" }, ];
    $scope.Operations = new Array();
    $scope.errorType = [{ "name": "ErrorCode" }, { "name": "Timeout" }, { "name": "Fatal" }, ];
    $scope.UGSReasonArray = [{ "name": "End of game", "id": 3 }, { "name": "Player canceled bet", "id": 7 }, { "name": "Winning", "id": 10 }, { "name": "Jackpo Winning", "id": 12 }, { "name": "Disconnection", "id": 2}];

    $scope.selectOperation = function (op) {
        $scope.selectedOperation = op.name;
        $scope.operationChosen = false;
        $scope.repeat = 1;
        $scope.originalIp = false;
        if (op.name == "UpdateGameState") {
            $scope.showUGS = true;
        } else {
            $scope.showUGS = false;
        }
        $scope.modifyOriginalIp();
    };

    $scope.SelectOperator = function (operator) {
        if (operator.name == "888") {
            $scope.Operations = $scope.ipOperations;
        } else {
            $scope.Operations = $scope.BipOperations;
        }
        $scope.selectedOperator = operator.name;
    };

    $scope.modifyOriginalIp = function () {
        if ($scope.selectedOperation != "EndGameSession" && $scope.selectedOperation != "CancelDebit") {
            $scope.originalIp = true;
        } else {
            $scope.originalIp = false;
        }
    };
    $scope.selectErrorType = function (er) {

        $scope.selectedError = er.name;
        if ($scope.selectedError == "Fatal") {
            $scope.originalIp = false;
            $scope.makeRepeatDisabled = true;
            $scope.repeat = 1;
        }
        else {
            $scope.makeRepeatDisabled = false;
        }
        $scope.modifyOriginalIp();
    };
    $scope.addError = function () {
        if ($scope.selectedError == "ErrorCode" && isNaN(parseInt($scope.errorCode))) {
            toastr['error']("Error Code must be a valid Number when Error Type is ErrorCode", "Oops an error has ocured!");
        } else if (isNaN(parseInt($scope.repeat))) {
            toastr['error']("Repeat must be a valid Number", "Oops an error has ocured!");
        } else {
            var error;
            if ($scope.errorCode == "")
                error = null;
            else
                error = parseInt($scope.errorCode);
            $scope.operationErrors.push({ "ErrorType": $scope.selectedError, "ErrorCode": parseInt($scope.errorCode), "Repeat": $scope.repeat, "ShouldCallOriginalIPOperation": $scope.originalIp, "id": new Date().getTime() });
        }
    };
    $scope.removeError = function (op) {

        for (var i = 0; i < $scope.operationErrors.length; i++) {
            if ($scope.operationErrors[i].id == op.id) {
                $scope.operationErrors.splice(i, 1);
                break;
            }
        }
    };

    $scope.addOperation = function () {
        if ($scope.ClientId == null || $scope.ClientId == '' || $scope.GameType == null || $scope.GameType == '') {
            toastr['error']("Client ID and Game Type cannot be null", "Oops an error has ocured!");
        } else if ($scope.selectedOperation == "UpdateGameState" && $scope.UGSReason == null) {
            toastr['error']("UGS Reason cannot be empty", "Oops an error has ocured!");
        } else
            if ($scope.operationErrors == null || $scope.operationErrors.length == 0) {
                toastr['error']("You must have at least one error type for this operation", "Oops an error has ocured!");
            } else {
                if ($scope.editedOperation != null) {
                    for (var i = 0; i < $scope.operations.length; i++) {
                        if ($scope.operations[i].id == $scope.editOperation.id)
                            $scope.operations[i] = { "Operation": $scope.selectedOperation, "Errors": $scope.operationErrors, "id": new Date().getTime() };
                    }
                } else {
                    $scope.operations.push({ "Operation": $scope.selectedOperation, "Errors": $scope.operationErrors, "UGSReason": $scope.UGSReason, "id": new Date().getTime(), "ClientId": parseInt($scope.ClientId), "GameType": parseInt($scope.GameType) });
                }
                $scope.showUGS = false;
                $scope.UGSReasonName = '';
                $scope.UGSReason = null;
                $scope.editedOperation = null;
                $scope.operationErrors = new Array();
                $scope.selectedOperation = '';
                $scope.repeat = '';
                $scope.erorCode = '';
                $scope.selectedError = '';
                $scope.originalIp = false;
                $scope.selectedOperator = '';
                $scope.Operations = new Array();
            }
    };
    $scope.moveUp = function (op) {
        for (var i = 0; i < $scope.operationErrors.length; i++) {
            if ($scope.operationErrors[i].id == op.id) {
                if (i > 0) {
                    var temp = $scope.operationErrors[i - 1];
                    $scope.operationErrors[i - 1] = $scope.operationErrors[i];
                    $scope.operationErrors[i] = temp;
                }
            }

        }
    };
    $scope.moveDown = function (op) {

        for (var i = 0; i < $scope.operationErrors.length; i++) {
            if ($scope.operationErrors[i].id == op.id) {
                if (i < $scope.operationErrors.length - 1) {
                    var temp = $scope.operationErrors[i + 1];
                    $scope.operationErrors[i + 1] = $scope.operationErrors[i];
                    $scope.operationErrors[i] = temp;
                }
            }

        }

    };
    $scope.editOperation = function (op) {

        $scope.selectedOperation = op.Operation;
        $scope.operationErrors = op.Errors;
        $scope.editedOperation = op.Operation;

    };
    $scope.deleteOperation = function (op) {

        for (var i = 0; i < $scope.operations.length; i++) {
            if ($scope.operations[i].id == op.id) {
                $scope.operations.splice(i, 1);
            }
        }

    };
    $scope.isFinalError = function () {
        if ($scope.selectedError == "Fatal" || ($scope.selectedError == "ErrorCode" && $scope.errorCode != "14" && $scope.errorCode != "15")) return true;
        return false;
    };
    $scope.formValidation = function () {
        if ($scope.ClientId == null) {
            toastr['error']("Client Id cannot be empty", "Oops an error has ocured!");
            return false;
        }
        if ($scope.GameType == null) {
            toastr['error']("Game Type cannot be empty", "Oops an error has ocured!");
            return false;
        }
        if ($scope.operations.length < 1) {
            toastr['error']("You need at least one Operation", "Oops an error has ocured!");
            return false;
        }
        return true;

    };
    $scope.checkIfErrorCode = function () {
        if ($scope.selectedError != "ErrorCode") {
            $scope.errorCode = "";
            return true;
        }
        return $scope.operationChosen;
    };
    $scope.checkIfRepeat = function () {
        if ($scope.makeRepeatDisabled) return true;
        return $scope.operationChosen;
    };
    $scope.checkIfOriginalIp = function () {
        if ($scope.isFinalError()) return true;
        return $scope.operationChosen;
    };
    $scope.ErrorCodeKeyPressed = function () {
        if ($scope.errorCode != 14 && $scope.errorCode != 15) {
            $scope.repeat = 1;
            $scope.makeRepeatDisabled = true;
        } else {
            $scope.makeRepeatDisabled = false;
        }
        if ($scope.isFinalError()) {
            $scope.originalIp = false;
        } else {
            $scope.originalIp = true;
        }
    };
    $scope.sendSimulation = function () {
        if ($scope.formValidation()) {
            $http.post(Gen_Config["simulatorServer"] + '/AddIntegrationPlatformErrorSimulation', $scope.operations).success(function (responseData) {
                if (responseData.Type == 'error') {
                    var log = {
                        Type: 'danger',
                        Message: responseData.Message
                    };
                } else {
                    var log = {
                        Type: responseData.Type,
                        Message: responseData.Message
                    };
                }
                $scope.$parent.logs.push(log);
                toastr[responseData.Type](responseData.Message, responseData.Title);
            }).
                error(function (data, status, headers, config) {
                    toastr['error']("Request failed with Status: " + status, "Oops an error has ocured!");
                });
            toastr['info']("Sumbmited Error simulation request for game " + $scope.GameType, "Simulation Sent!");
        }
        saveCidInCookie($scope.ClientId);
    };
    $scope.selectCid = function (cid) {
        $scope.ClientId = cid;
    };
    $scope.selectUGS = function (ugs) {
        $scope.UGSReasonName = ugs.name;
        $scope.UGSReason = ugs.id;

    };
    NProgress.done();
});
/*-----------------------------------------------------------------------------------------------------------------*/

